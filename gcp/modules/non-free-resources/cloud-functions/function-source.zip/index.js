exports.handler = (req, res) => {
  res.send('Hello from privesc function!');
};
